public interface Stack{
	public void push(Object obj);
	public Object peek();
	public Object pop();
	public int size();
}